<?php

namespace App\Http\Controllers;


use Illuminate\Http\Request;
use App\Models\Student;

class homecontroller extends Controller
{
    public function get_student(Request $request){
        if(empty($request->id))
            $data = Student::all();
        else
            $data = Student::find($request->id);
        return json_encode($data);
    }

    public function post_student(Request $request){
        $student = new Student;
        $student->name = $request->name;
        $student->address = $request->address;
        $student->date_of_birth = $request->date_of_birth;
        $student->place_of_birth = $request->place_of_birth;
        $student->gender = $request->gender;
        $student->class = $request->class;
        $student->program_study = $request->program_study;
        
        if($student->save()){
            return json_encode([
                'message' => 'Success'
            ]);
        }else{
            return json_encode([
                'message' => 'Fail'
            ]);
        }
    }
}



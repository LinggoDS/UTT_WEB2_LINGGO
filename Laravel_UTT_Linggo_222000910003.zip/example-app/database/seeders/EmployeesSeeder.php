<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class EmployeesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('employees')->insert([
            'nip' => '222000910003',
            'name' => 'Linggo D. Soemargo',
            'date_of_birth' => '18/11/2000',
            'place_of_birth' => 'Jakarta',
            'address' => 'Jl. Tukad Sari Kuning No.3',
            'email' => 'linggosoemargo@gmail.com',
            'phone_number' => '081337745356',
            'salary' => '2000000',
            'status' => 'active'
        ]);

        DB::table('employees')->insert([
            'nip' => '222000910006',
            'name' => 'Michael Nathaniel',
            'date_of_birth' => '24/12/2004',
            'place_of_birth' => 'Denpasar',
            'address' => 'Jl. Padang Udayana No.7',
            'email' => 'mikenatahniel01@gmail.com',
            'phone_number' => '081238207287',
            'salary' => '2000000',
            'status' => 'active'
        ]);
    }
}

<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use App\Models\Student;

class StudentSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $student = new Student;
        $student->name = 'Putu Gede Danandra Prana Lesmana';
        $student->address = 'Gianyar';
        $student->date_of_birth = '2002-11-17';
        $student->place_of_birth = 'Gianyar';
        $student->gender = 'L';
        $student->class = 'PRDM2023';
        $student->program_study = 'Digital Marketing';
        $student->save();
    //    DB::table('students')->insert([
    //     'name' => 'Linggo Dianputra Soemargo',
    //     'address' => 'Denpasar',
    //     'date_of_birth' => '2000-12-17',
    //     'place_of_birth' => 'Jakarta',
    //     'gender' => 'L',
    //     'class' => 'WPMA2023',
    //     'program_study' => 'Web Programming'
    //    ]);

    //    DB::table('students')->insert([
    //     'name' => 'Michael Nathaniel',
    //     'address' => 'Denpasar',
    //     'date_of_birth' => '2004-03-18',
    //     'place_of_birth' => 'Denpasar',
    //     'gender' => 'L',
    //     'class' => 'WPMA2023',
    //     'program_study' => 'Web Programming'
    //    ]);
    }
}
